﻿using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nop.Admin.Models.Users
{
    public partial class UserModel : BaseNopEntityModel

    {
        [NopResourceDisplayName("Admin.UserMaster.Fields.FristName")]
        public string FristName { get; set; }

        [NopResourceDisplayName("Admin.UserMaster.Fields.LastName")]
        public int LastName { get; set; }

        [NopResourceDisplayName("Admin.UserMaster.Fields.Password")]
        public string Password { get; set; }

        [NopResourceDisplayName("Admin.UserMaster.Fields.Email")]
        public string Email { get; set; }
        [NopResourceDisplayName("Admin.UserMaster.Fields.Phone")]
        public string Phone { get; set; }
    }
}