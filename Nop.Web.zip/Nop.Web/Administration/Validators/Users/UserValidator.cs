﻿using Nop.Admin.Models.Users;
using Nop.Core.Domain.Users;
using Nop.Data;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nop.Admin.Validators.Users
{
    public partial class UserMasterValidator : BaseNopValidator<UserModel>

     {

        public UserMasterValidator(ILocalizationService localizationService, IDbContext dbContext)
        {
           // RuleFor(x => x.Password).NotEmpty().WithMessage(localizationService.GetResource("Admin.UserMaster.Fields.Name.Required"));

            SetStringPropertiesMaxLength<User>(dbContext);
        }
    }
}