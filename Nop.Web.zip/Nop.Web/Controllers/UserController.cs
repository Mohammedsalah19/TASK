﻿using Nop.Admin.Extensions;
using Nop.Admin.Models.Users;
using Nop.Core.Domain.Profile;
using Nop.Data;
using Nop.Services.Users;
using Nop.Web.Framework.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nop.Web.Controllers
{
    public class UserController : Controller
    {
        #region Fields

        private readonly IUserService _userMasterService;
      //  private NopObjectContext _db =new NopObjectContext();

        #endregion

        #region Constructors

        public UserController(IUserService userMasterService)
        {
            this._userMasterService = userMasterService;
        }

        #endregion

        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Create()
        {
           

            var model = new UserModel();

            return View(model);
        }

        [HttpPost]
        public ActionResult Create(ProfileX model, string FristName)
        {
                 model.FristName = FristName;
               // _db.ProfileX.Add(model);
                //_db.SaveChanges();
 
            return RedirectToAction("List");
        }


        public ActionResult Communities()
        {
 
            return View();
        }

        public ActionResult Register()
        {

            return View();
        }

    }
}