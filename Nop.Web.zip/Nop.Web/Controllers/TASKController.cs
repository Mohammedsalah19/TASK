﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Nop.Web.Controllers
{
    public class TASKController : Controller
    {
        // GET: TASK
  
        [ChildActionOnly]
        public virtual ActionResult Counter()
        {
 
            return PartialView();
        }
    }
}